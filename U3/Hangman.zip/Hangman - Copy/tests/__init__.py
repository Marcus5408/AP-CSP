# the various test cases im required to do

# w = pick_secret_word()
# print("Secret word is " + w)

# secret_word = "DOKJA"
# secret_word_list = create_secret_word_list(secret_word)
# print(secret_word_list)

# secret_word_list = ["S", "A", "D"]
# guessed_letters = create_guessed_letter_list(secret_word_list)
# print(guessed_letters)

# secret_word_list = ["J", "O", "O", "N", "G", "H", "Y", "U", "K"]
# guessed_letters = create_guessed_letter_list(secret_word_list)
# print(guessed_letters)

# test = ["L", "__", "R", "E", "M", "I", "P", "S", "__", "M"]
# print_guessed_letters(test)

# test_list = ["S", "A", "D"]
# test1 = check_letter(test_list, "A")
# print(test1)
# test2 = check_letter(test_list, "E")
# print(test2)

# test_list = ["H", "A", "N", "S", "O", "O", "Y", "O", "U", "N", "G"]
# test1 = check_letter(test_list, "S")
# print(test1)
# test2 = check_letter(test_list, "J")
# print(test2)

# t1_word = ["D", "I", "A", "M", "O", "N", "D"]
# t1_guessed = ["__", "__", "A", "__", "__", "N", "__"]
# t1_letter = "D"
# t1_guessed_new = update_guessed_letters(t1_word, t1_guessed, t1_letter)
# print(t1_guessed_new)

# t1_word = ["B", "I", "Y", "O", "O"]
# t1_guessed = ["__", "__", "Y", "__", "__"]
# t1_letter = "O"
# t1_guessed_new = update_guessed_letters(t1_word, t1_guessed, t1_letter)
# print(t1_guessed_new)

# test1 = ["B", "I", "H", "Y", "U", "N", "G"]
# test2 = ["D", "__", "K", "K", "A", "__", "B", "I"]
# print(is_word_guessed(test1))
# print(is_word_guessed(test2))